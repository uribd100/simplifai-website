# לוגיקת סינון + חילוץ פרופיל + בדיקת זמינות

## 1. חילוץ פרופיל מובנה (מתבסס על Shagi — Gemini→Make, חילוץ JSON מהודעות)

הסוכן מחלץ מההודעות אובייקט מובנה. ה-LLM עושה זאת תוך כדי שיחה (אין צורך בצומת נפרד ב-Pro), אבל זו הסכמה לוודא עקביות:

```json
{
  "name": "string|null",
  "language": "he|en|ru",
  "check_in": "YYYY-MM-DD|null",
  "check_out": "YYYY-MM-DD|null",
  "party_size": "int|null",
  "has_children": "bool|null",
  "group_type": "family|couple|friends|event|unknown",
  "stated_purpose": "string|null",
  "property_interest": "property_id|null"
}
```

## 2. מנוע ההחלטה (rule engine — רץ בראש ה-LLM לפי ה-system prompt)

```
INPUT: profile + property facts (תפוסה מקסימלית, כללי בית)

1. occupancy_fit = party_size <= max_occupancy(property)
2. intent_fit    = group_type NOT IN ('event')
                   AND stated_purpose NOT MATCHING ['מסיבה','אירוע','party','rave','חגיגה רועשת']
3. rules_fit     = אין סתירה לכללי הבית (חיות/עישון/שעות — לפי facts)

DECISION:
  if  occupancy_fit AND intent_fit AND rules_fit            -> FIT      (בדוק זמינות → ליד חם → notify_host hot)
  if  NOT occupancy_fit AND קיים נכס גדול יותר פנוי         -> REROUTE  (הצע נכס מתאים)
  if  NOT intent_fit OR NOT rules_fit                       -> UNFIT    (דחייה מנומסת, ללא העברה)
  else (ambiguous / על הגבול)                               -> BORDERLINE (notify_host borderline + human)
```

🔴 **אין שדה גיל ואין החלטה לפי גיל.** ההגנה המשפטית (חוק איסור הפליה התשס"א-2000) מבוססת על כך שהסינון הוא על **התאמה לתפוסה ולכללי בית מבוססי-התנהגות** (אירועים/רעש), לא על מאפיין מוגן. ראה §6 ב-FINAL.md.

## 3. בדיקת זמינות — חייבת זמן-אמת (דרישת לקוח קשיחה)

🔴 **הבוט חייב לדעת בכל רגע את מצב ההזמנות — אסור להציע תאריך תפוס.** `check_availability(property_id, check_in, check_out)` ממומש כ-sub-workflow, אבל **מקור-האמת חייב להיות מסונכרן בזמן אמת:**

| מקור | זמן-אמת | מימוש | סיכון double-booking |
|---|---|---|---|
| channel manager API (Guesty/Smoobu/Beds24/Hostaway/Lodgify) | ✅ אמיתי | HTTP Request ל-API + webhook על שינוי הזמנה | נמוך — **מומלץ** |
| iCal (Airbnb/Booking) | ⚠️ השהיית ~2-3 שעות | iCal parser + polling צפוף | **קיים בחלון ההשהיה** — חובה שכבת hold |
| Google Calendar משותף | ✅ אם מתעדכן מיד | Google Console OAuth (Shagi, משה כהן) | תלוי משמעת ידנית |

**שכבת בטיחות חובה (תמיד, גם עם API):**
1. בדיקת זמינות → אם פנוי, סימון **hold זמני** (15-30 דק') למניעת מרוץ בין שתי פניות במקביל.
2. הבוט **לא סוגר סופית** — מעביר ליד חם; הסגירה הסופית (אנושית או Premium) מאמתת מול מקור-האמת שוב.
3. ב-iCal בלבד: רענון לפני כל מענה זמינות + לתקשר לאודי את מגבלת ההשהיה.

### iCal fallback — לוגיקה (Code node בתוך sub-workflow)
```
1. GET {{ICAL_URL_FOR_PROPERTY}}  (קישור ייצוא מ-Airbnb/Booking)
2. parse VEVENT blocks → רשימת טווחים תפוסים [{start,end}]
3. overlap = any(busy.start < check_out AND busy.end > check_in)
4. return { available: !overlap, busy_ranges: [...], source_age_minutes: N }
```
> אם `source_age_minutes` גבוה — הבוט עונה "בודק מול היומן ומאשר תוך דקות" במקום הבטחה מיידית, כדי לא להבטיח על דאטה ישנה.

## 4. CRM — log_lead (מתבסס על Nate — Personal Assistant Agent: עדכון Google Sheets)

כל פנייה → שורה ב-Google Sheets / Airtable:

| timestamp | name | phone | language | check_in | check_out | party_size | group_type | fit_decision | property_id | notes |
|---|---|---|---|---|---|---|---|---|---|---|

מאפשר למארח: לראות כל מי שפנה, שיעור התאמה, נכס מבוקש, ומקור לאנליטיקה (דשבורד ב-Premium).

## 5. Human handoff
- כל פנייה FIT או BORDERLINE → `notify_host` (WhatsApp/מייל למארח עם סיכום בעברית).
- אורח שמבקש אדם במפורש → notify_host מיידי.
- כשל בכלי (זמינות/ידע) → הסוכן אומר "נציג יחזור אליך" + notify_host (לא משאיר אורח תקוע).

## 6. מקורות KB
- Shagi — *חיבור Gemini ל-Make*: חילוץ JSON מובנה מהודעות + סיווג ליד. (1737638212136/pLytdbQ)
- Shagi — *חיבור Google Calendar ל-n8n* דרך Google Console OAuth. (1756354239715/0soV99w)
- Shagi — *FAST BOTS*: אימון בוט על בסיס ידע; אזהרה — "אל תצפו ל-90% דיוק בהתחלה". (1737638212136/kOUvx6M)
- Nate — *Email Manager AI Agent*: סיווג לקטגוריות + פעולות אוטומטיות + handoff בטלגרם. (free-n8n-templates/82099edd)
- Nate — *Personal Assistant AI Agent*: tool-calling, עדכון Sheets, ניהול יומן. (free-n8n-templates/a66130d5)
