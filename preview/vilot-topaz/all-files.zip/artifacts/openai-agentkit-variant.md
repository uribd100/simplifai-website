# וריאנט E — OpenAI AgentKit (מסלול בנייה חלופי ל-n8n)

> מקור: Brainers KB — `brainers-library/library/tools/openai-agentkit.md` (idx-28). AgentKit שוחרר אוקטובר 2025: Agent Builder (בונה ויזואלי no-code), ספריית connectors, ChatKit לפריסה חיצונית, ו-MCP. ממוקם "בין Make ל-n8n" בקלות השימוש.
> מטרה: לתת לך (Uri) מסלול בנייה שני להשוואה. **לא** מוצר נפרד ללקוח — אודי בוחר חבילה+תמחור, אתה בוחר מסלול בנייה.

---

## מתי לבחור AgentKit על פני n8n
| שיקול | AgentKit | n8n |
|---|---|---|
| מהירות הקמת ה-agent | ✅ מהיר יותר (הכל תחת OpenAI — מודל+orchestration+deploy) | בינוני |
| הבנת שפה / reasoning | ✅ native OpenAI | ✅ (דרך OpenAI node) |
| Guardrails מובנים | ✅ node ייעודי | ידני |
| חיבור ל-WhatsApp | ⚠️ **לא native** — דורש bridge (ChatKit ל-web, או middleware ל-WhatsApp BSP) | ✅ HTTP ישיר ל-BSP |
| חיבור channel manager / iCal / Sheets | דרך connectors / MCP / function tools | ✅ HTTP/nodes ישיר |
| self-host / margin בריטיינר | ❌ נעול ל-OpenAI, עלות per-token | ✅ self-host = margin גבוה |
| שכפול ל-50 לקוחות (קו מוצר) | בינוני | ✅ template + duplicate |

**שורה תחתונה:** AgentKit = POC מהיר ויפה ל-reasoning. n8n נשאר ה**מומלץ ל-production** בגלל חיבור WhatsApp ישיר + self-host margin + שכפוליות. השתמש ב-AgentKit אם רוצים להעלות דמו חי תוך יום-יומיים, או אם הלקוח כבר ב-OpenAI ecosystem.

---

## ארכיטקטורה ב-AgentKit

```
[WhatsApp Inbound — BSP 360dialog webhook]
        ↓  (bridge — לא native ב-AgentKit)
[Middleware קל — Cloudflare Worker / Vercel function / n8n דק]
   ממיר payload של 360dialog → קריאה ל-AgentKit (Agents SDK / API)
        ↓
[AgentKit — Agent Builder flow]
   Start
   → Guardrails (שפה, תוכן, anti-discrimination check)
   → Agent (system prompt = agent-system-prompt.md, model gpt-4o/4o-mini)
        Tools:
          • check_availability (function tool → HTTP ל-channel manager API / iCal)  ← זמן-אמת
          • get_property_facts (function tool / File Search על בסיס ידע)
          • log_lead (function tool → Google Sheets/Airtable, או MCP)
          • notify_host (function tool → WhatsApp/Email)
   → If/Else (FIT / UNFIT / BORDERLINE)
   → End (מחזיר תשובת טקסט)
        ↓
[Middleware שולח את התשובה חזרה ל-360dialog → WhatsApp]
```

### Nodes ב-Agent Builder (מ-Brainers KB)
`Start · Agent · Tools · Guardrails · MCP · Logic/If-Else · End` — drag-and-drop, ללא קוד.

### Tools — אותה חתימה כמו ב-n8n (function calling)
| tool | תיאור | מימוש |
|---|---|---|
| `check_availability` | זמן-אמת, אסור תאריך תפוס | function tool → HTTP ל-channel manager API (מומלץ) / iCal (עם hold) |
| `get_property_facts` | facilities/מחיר/שעות/כללי בית | function tool, או **File Search** של AgentKit על מסמך הנכסים |
| `log_lead` | רישום ליד | function tool → Sheets/Airtable, או connector/MCP |
| `notify_host` | התראת ליד חם / handoff | function tool → WhatsApp/Email |

### Guardrails (יתרון של AgentKit)
- חסימת ניסוחים מפלים (anti-discrimination — §6 ב-FINAL.md): guardrail שמוודא שהדחייה מנוסחת לפי כללי-בית, לא לפי גיל.
- הגבלת נושאים מחוץ ל-scope (לא ייעוץ משפטי/תשלומים מחוץ למסגרת).

### Deployment — ChatKit
- ChatKit מאפשר widget צ'אט באתר/אפליקציה. **ל-WhatsApp** עדיין צריך bridge (BSP webhook ↔ AgentKit API). ChatKit לבד = ערוץ web, לא WhatsApp.

---

## עלויות (להשוואה מול n8n ~₪250-500/חו')
- OpenAI per-token (gpt-4o-mini זול; gpt-4o יקר יותר) — משתנה לפי נפח שיחות.
- WhatsApp BSP (360dialog) — כמו ב-n8n.
- Middleware (Worker/Vercel) — זניח/חינם בנפח נמוך.
- **אין self-host margin** כמו n8n → בריטיינר, ה-margin נמוך יותר. שקלל בתמחור.

---

## המלצה
- **דמו מהיר / לקוח ב-OpenAI ecosystem** → AgentKit.
- **production + קו מוצר ל-50 מארחים + margin בריטיינר** → n8n (Variant B, המומלץ).
- אפשר היברידי: AgentKit ל-reasoning+guardrails, n8n ל-orchestration+integrations. מורכב יותר — לא לפיילוט ראשון.

## מקור
- Brainers — *OpenAI AgentKit* (idx-28): Agent Builder nodes, connectors, ChatKit, MCP, "בין Make ל-n8n". `brainers-library/library/tools/openai-agentkit.md`
