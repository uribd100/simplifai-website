# וריאנט ManyChat — חבילת Basic ("המסנן")

> ManyChat הוא builder ויזואלי — **אין import JSON**. זהו spec מלא לבנייה ידנית ב-UI (Automation → Flows), כולל keywords, blocks, conditions ו-External Request לבדיקת זמינות.
> מתאים ל-**Basic**: מהיר, זול (~$15/חו'), מבוסס כפתורים + תפיסת keywords. לא AI agent מלא — לשפה חופשית/רב-לשוני/ריבוי-נכסים מורכב → Pro ב-n8n.
> דרוש: ManyChat Pro + ערוץ WhatsApp מחובר (ManyChat הוא BSP מאושר ל-WhatsApp).

---

## ארכיטקטורת ה-Flow (עץ)

```
[Default Reply / Keyword Trigger]
        ↓
[Welcome — שאלת פתיחה + Quick Reply buttons]
   ├── "מחיר" ───────────────→ [Flow: מחיר]
   ├── "זמינות / תאריכים" ────→ [Flow: זמינות]  (External Request)
   ├── "מה יש בבית / facilities" → [Flow: Facilities]
   ├── "שעות כניסה/יציאה" ────→ [Flow: שעות]
   └── "לדבר עם נציג" ────────→ [Flow: Human Handoff]
        ↓ (בכל flow, בסוף)
[Qualify — 3 כפתורים: כמה אתם? / מטרת השהייה]
        ↓
[Condition: סינון]
   ├── מתאים ──→ [שליחת פרטים + Notify owner (Email/Telegram/WA)]
   └── לא מתאים → [נוסח דחייה מנומס]
```

---

## Triggers (Settings → Keywords)
| Trigger | מילים | פעולה |
|---|---|---|
| Welcome | "היי", "שלום", "hi", כל הודעה ראשונה | Welcome flow |
| מחיר | "מחיר", "כמה עולה", "price", "цена" | Flow מחיר |
| זמינות | "פנוי", "תאריכים", "available", "free" | Flow זמינות |
| facilities | "מה יש", "בריכה", "חניה", "amenities" | Flow Facilities |
| שעות | "כניסה", "יציאה", "check in", "checkout" | Flow שעות |
| נציג | "נציג", "בנאדם", "אדם", "agent", "human" | Handoff |

> מגבלה ידועה: keywords לא מבינים שפה חופשית מורכבת. ב-Welcome תמיד הצג Quick Reply buttons כדי לנתב — זה הפתרון של Basic.

---

## Blocks לכל Flow

### Welcome
- Text: "היי! 👋 הגעת לוילות טופז באילת. במה אפשר לעזור?"
- Quick Replies (buttons): `מחיר` · `תאריכים פנויים` · `מה יש בבית` · `שעות כניסה/יציאה` · `לדבר עם נציג`

### Flow: מחיר
- Text (מתוך Custom Fields / טקסט קבוע): "המחיר ללילה משתנה לפי עונה. לאיזה תאריכים?"
- Quick Reply → מוביל ל-Flow זמינות (כדי לאסוף תאריכים).

### Flow: זמינות (החלק היחיד שדורש API)
1. **User Input** (Date) → שמור ל-Custom Field `check_in`
2. **User Input** (Date) → `check_out`
3. **External Request block** (ManyChat Pro):
   - Method: POST
   - URL: `{{AVAILABILITY_ENDPOINT}}` (אותו endpoint כמו ב-Pro — sub-workflow/iCal)
   - Body: `{"property_id":"villa-topaz-1","check_in":"{{check_in}}","check_out":"{{check_out}}"}`
   - Response Mapping: `available` → Custom Field `is_available`
4. **Condition** on `is_available`:
   - true → "מעולה, התאריכים פנויים! 🎉 המחיר ללילה: ₪___. רוצה שנציג יחזור אליך לסגירה?" → Qualify
   - false → "התאריכים האלה תפוסים. יש לך גמישות? אשמח לבדוק תאריכים אחרים."

### Flow: Facilities
- Text קבוע לכל נכס (Basic = נכס יחיד): רשימת facilities + שעות + כללי בית.

### Flow: שעות
- Text: "צ'ק-אין מ-15:00, צ'ק-אאוט עד 11:00." (מותאם בגילוי)

### Qualify (סינון — מבוסס התאמה, לא גיל)
1. Quick Reply: "כמה אתם?" → `1-4` / `5-6` / `7+` → Custom Field `party_size`
2. Quick Reply: "מטרת השהייה?" → `חופשה משפחתית` / `חופשה זוגית` / `אירוע/חגיגה` → `group_type`
3. **Condition (סינון):**
   - `group_type = אירוע/חגיגה` **או** `party_size = 7+` (מעל תפוסה) → **לא מתאים**
   - אחרת → **מתאים**

### מתאים → Notify owner
- **External Request / Email / Telegram** → התראה לאודי: "ליד חם: {{first_name}}, {{party_size}}, {{check_in}}-{{check_out}}, {{group_type}}. טלפון: {{phone}}."
- Text לאורח: "תודה! נציג יחזור אליך בהקדם לסגירת ההזמנה. 🌴"

### לא מתאים → דחייה מנומסת
- Text: "תודה רבה על הפנייה! הווילות שלנו מותאמות לחופשה משפחתית/זוגית שקטה לפי כללי בית של ללא אירועים ומסיבות, ולכן כנראה שלא נוכל להתאים הפעם. חופשה נעימה! 🙏"
- (אין Notify owner — חוסך לאודי את הרעש.)

### Handoff
- Text: "מעביר אותך לנציג, נחזור אליך בהקדם 🙌" + Notify owner (urgency: human).

---

## Custom Fields להגדיר
`check_in` (Date) · `check_out` (Date) · `is_available` (Text/Boolean) · `party_size` (Text) · `group_type` (Text) · `phone` (System) · `first_name` (System)

---

## מגבלות מול וריאנט Pro (n8n) — לתקשר ללקוח
| | ManyChat (Basic) | n8n (Pro) |
|---|---|---|
| שפה חופשית | ❌ keywords + כפתורים | ✅ הבנת שפה מלאה |
| רב-לשוני אוטומטי | ⚠️ ידני לכל שפה | ✅ אוטומטי |
| ריבוי נכסים + הפניה חכמה | ⚠️ מסורבל | ✅ |
| בדיקת זמינות | ✅ (External Request) | ✅ |
| מייל באותו מוח | ❌ (WhatsApp בלבד) | ✅ |
| עלות/חו' | ~$15 | ~$40-80 |
| זמן הקמה | 1-2 ימים | 4-7 ימים |

→ ManyChat = נקודת כניסה זולה. שדרוג טבעי ל-Pro כשהלקוח רוצה שפה חופשית/מייל/ריבוי נכסים.

## מקור KB
- Shagi — שיעורי ManyChat ב-`automation-school/library/automation-4/` (8xv0kc8, cm1YNM0, FrpiK3E) ו-`1756354239715/` (vpL5tdc, YPZ0iGo) — בניית בוט, keywords, External Request.
- עיקרון FastBots (kOUvx6M): "אל תצפו ל-90% דיוק בהתחלה" — כיול מתמשך גם ב-ManyChat.
